import threading
import time
import tkinter as tk
from tkinter import messagebox
from pynput import mouse, keyboard

# C:/Users/bayro/Desktop/Dyzer.py
# Autoclicker "zChisu Dyzer"
# Requires: pynput
# pip install pynput


TITLE = "zChisu Dyzer"
MAX_CPS = 20

class DyzerAutoClicker:
    def __init__(self, root):
        self.root = root
        root.title(TITLE)

        self.left_cps = tk.DoubleVar(value=10.0)
        self.right_cps = tk.DoubleVar(value=10.0)
        self.hotkey_text = tk.StringVar(value="ctrl+shift+z")
        self.enabled = False

        self._ignore_lock = threading.Lock()
        self._ignore = False

        self._left_active = False
        self._right_active = False
        self._left_stop = threading.Event()
        self._right_stop = threading.Event()

        self.mouse_controller = mouse.Controller()
        self.klistener = None
        self.mlistener = None

        self._build_gui()
        self._start_mouse_listener()
        self._start_hotkey_listener(self.hotkey_text.get())

    def _build_gui(self):
        frame = tk.Frame(self.root, padx=10, pady=10)
        frame.pack()

        tk.Label(frame, text="Left CPS (0-20):").grid(row=0, column=0, sticky="w")
        tk.Spinbox(frame, from_=0, to=MAX_CPS, increment=0.1, textvariable=self.left_cps, width=6).grid(row=0, column=1)

        tk.Label(frame, text="Right CPS (0-20):").grid(row=1, column=0, sticky="w")
        tk.Spinbox(frame, from_=0, to=MAX_CPS, increment=0.1, textvariable=self.right_cps, width=6).grid(row=1, column=1)

        tk.Label(frame, text="Hotkey (e.g. ctrl+shift+z):").grid(row=2, column=0, sticky="w")
        tk.Entry(frame, textvariable=self.hotkey_text, width=20).grid(row=2, column=1)

        self.toggle_btn = tk.Button(frame, text="Enable (Hotkey to toggle)", command=self.toggle_enabled)
        self.toggle_btn.grid(row=3, column=0, columnspan=2, pady=8)

        tk.Button(frame, text="Apply Hotkey", command=self._apply_hotkey).grid(row=4, column=0, columnspan=2, pady=(0,6))

        self.status_label = tk.Label(frame, text="Disabled", fg="red")
        self.status_label.grid(row=5, column=0, columnspan=2)

        root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _set_ignore(self, v):
        with self._ignore_lock:
            self._ignore = v

    def _get_ignore(self):
        with self._ignore_lock:
            return self._ignore

    def _start_mouse_listener(self):
        def on_click(x, y, button, pressed):
            if self._get_ignore():
                return  # ignore synthetic clicks we generate

            if not self.enabled:
                return

            if pressed:
                # physical press detected
                if button == mouse.Button.left and self.left_cps.get() > 0 and not self._left_active:
                    self._left_stop.clear()
                    t = threading.Thread(target=self._click_loop, args=(mouse.Button.left, self.left_cps, self._left_stop, '_left_active'))
                    t.daemon = True
                    self._left_active = True
                    t.start()
                elif button == mouse.Button.right and self.right_cps.get() > 0 and not self._right_active:
                    self._right_stop.clear()
                    t = threading.Thread(target=self._click_loop, args=(mouse.Button.right, self.right_cps, self._right_stop, '_right_active'))
                    t.daemon = True
                    self._right_active = True
                    t.start()
            else:
                # release -> stop corresponding loop
                if button == mouse.Button.left:
                    self._left_stop.set()
                elif button == mouse.Button.right:
                    self._right_stop.set()

        self.mlistener = mouse.Listener(on_click=on_click)
        self.mlistener.daemon = True
        self.mlistener.start()

    def _click_loop(self, button, cps_var, stop_event, active_attr_name):
        try:
            interval = max(0.001, 1.0 / max(0.0001, cps_var.get()))
        except Exception:
            interval = 0.1
        while not stop_event.is_set() and self.enabled:
            # send a click, but mark ignore so listener won't react
            self._set_ignore(True)
            try:
                self.mouse_controller.click(button)
            finally:
                # small delay to make sure listener sees ignore flag during synthetic events
                time.sleep(0.001)
                self._set_ignore(False)
            time.sleep(interval)
        setattr(self, active_attr_name, False)

    def toggle_enabled(self):
        self.enabled = not self.enabled
        self.status_label.config(text="Enabled" if self.enabled else "Disabled", fg="green" if self.enabled else "red")

    def _apply_hotkey(self):
        hk = self.hotkey_text.get().strip()
        if not hk:
            messagebox.showerror("Error", "Hotkey cannot be empty")
            return
        self._start_hotkey_listener(hk)
        messagebox.showinfo("Hotkey", f"Hotkey set to: {hk}")

    def _format_hotkey_for_pynput(self, s):
        parts = [p.strip().lower() for p in s.split("+") if p.strip()]
        out = []
        for p in parts:
            if p in ("ctrl", "control"):
                out.append("<ctrl>")
            elif p == "alt":
                out.append("<alt>")
            elif p == "shift":
                out.append("<shift>")
            elif p in ("enter", "return"):
                out.append("<enter>")
            elif p in ("space",):
                out.append("<space>")
            elif p in ("tab",):
                out.append("<tab>")
            elif p in ("esc", "escape"):
                out.append("<esc>")
            elif p.startswith("f") and p[1:].isdigit():
                out.append(p)
            else:
                out.append(p)
        return "+".join(out)

    def _start_hotkey_listener(self, hotkey_str):
        # stop existing
        if self.klistener:
            try:
                self.klistener.stop()
            except Exception:
                pass
            self.klistener = None

        hk = self._format_hotkey_for_pynput(hotkey_str)
        try:
            self.klistener = keyboard.GlobalHotKeys({hk: self.toggle_enabled})
            self.klistener.daemon = True
            self.klistener.start()
        except Exception as e:
            messagebox.showerror("Hotkey error", f"Failed to register hotkey: {e}")

    def _on_close(self):
        # stop listeners and threads
        try:
            if self.mlistener:
                self.mlistener.stop()
        except Exception:
            pass
        try:
            if self.klistener:
                self.klistener.stop()
        except Exception:
            pass
        self._left_stop.set()
        self._right_stop.set()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = DyzerAutoClicker(root)
    root.mainloop()